var someInts = [Int]()

someInts.append(10)

var favVideoGames: [String] = ["Apex Legends","Assassin's Creed","Hyper Scape", "Brawlhalla", "Roblox","Paladins","Call of Duty","Spongebob: Rehydrated","Super Smash Bros", "Mario Kart"]

print("The video games list contains \(favVideoGames.count) items.")
